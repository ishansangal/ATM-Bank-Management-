package bank.management.system;

import java.sql.*;

public class Conn {
    
    Connection c;
    
    Statement s;
    public Conn(){
    try {
         c = DriverManager.getConnection("jdbc:mysql:///bankmanagemtensystem", "root", "mysql@dbms");
         s = (bank.management.system.Statement) c.createStatement();
         
    } catch (Exception e) {
     System.out.println(e);
   
    }
  }
    
}

