package bank.management.system;

import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class SingupThree extends JFrame implements ActionListener {
            JRadioButton r1,r2,r3,r4;
            JCheckBox s1,s2,s3,s4,s5,s6,s7;
            JButton submit,cancel;
            String formno;
    
    SingupThree(String formno){
    this.formno = formno;
        setLayout(null);
       
        
        JLabel l1 = new JLabel("Page-3: Account Details");
        l1.setFont(new Font("Raleway", Font.BOLD,22));
        l1.setBounds(280,40,400,40);
        add(l1);
        
        JLabel type = new JLabel("Account Type");
        type.setFont(new Font("Raleway", Font.BOLD,18));
        type.setBounds(100,140,200,40);
        add(type);
        
        r1= new JRadioButton("Saving Account");
        r1.setFont(new Font("Raleway", Font.BOLD,16));
        r1.setBackground(Color.WHITE);
        r1.setBounds(100,190,200,40);
        add(r1);

        r2= new JRadioButton("Fixed Deposit Account");
        r2.setFont(new Font("Raleway", Font.BOLD,16));
        r2.setBackground(Color.WHITE);
        r2.setBounds(100,240,200,40);
        add(r2);

        r3= new JRadioButton("Current Account");
        r3.setFont(new Font("Raleway", Font.BOLD,16));
        r3.setBackground(Color.WHITE);
        r3.setBounds(300,190,200,40);
        add(r3);
        
          r4= new JRadioButton("Recurring Depostie Account");
        r4.setFont(new Font("Raleway", Font.BOLD,16));
        r4.setBackground(Color.WHITE);
        r4.setForeground(Color.BLACK);
        r4.setBounds(300,240,250,40);
        add(r4);
        
        ButtonGroup groupaccount = new ButtonGroup();
        groupaccount.add(r1);
                groupaccount.add(r2);
                groupaccount.add(r3);
                        groupaccount.add(r4);
                        
                        
        JLabel card = new JLabel("Card Number");
        card.setFont(new Font("Raleway", Font.BOLD,18));
        card.setBounds(100,300,200,40);
        add(card);
        
                JLabel cardnumber = new JLabel("XXXX-XXXX-XXXX-0001");
        cardnumber.setFont(new Font("Raleway", Font.BOLD,18));
        cardnumber.setBounds(300,300,300,40);
        add(cardnumber);
        
        JLabel carddetail = new JLabel("Your 16 digit Card Number");
        carddetail.setFont(new Font("Raleway", Font.BOLD,10));
        carddetail.setBounds(100,320,300,40);
        add(carddetail);
        
         JLabel pin = new JLabel("PIN Number");
        pin.setFont(new Font("Raleway", Font.BOLD,18));
        pin.setBounds(100,350,200,40);
        add(pin);
        
                JLabel pinnumber = new JLabel("XX01");
        pinnumber.setFont(new Font("Raleway", Font.BOLD,18));
        pinnumber.setBounds(300,350,200,40);
        add(pinnumber);
        
        JLabel pindetail = new JLabel("Your 4 digit Card Number");
        pindetail.setFont(new Font("Raleway", Font.BOLD,10));
        pindetail.setBounds(100,370,300,40);
        add(pindetail);
        
        JLabel services = new JLabel("Services Required");
        services.setFont(new Font("Raleway", Font.BOLD,18));
        services.setBounds(100,400,200,40);
        add(services);
        
          s1= new JCheckBox("ATM Card");
        s1.setFont(new Font("Raleway", Font.BOLD,16));
        s1.setBackground(Color.WHITE);
        s1.setBounds(100,450,200,40);
        add(s1);

          s2= new JCheckBox("Mobile Banking");
        s2.setFont(new Font("Raleway", Font.BOLD,16));
        s2.setBackground(Color.WHITE);
        s2.setBounds(300,450,200,40);
        add(s2);

          s3= new JCheckBox("Internet Banking");
        s3.setFont(new Font("Raleway", Font.BOLD,16));
        s3.setBackground(Color.WHITE);
        s3.setBounds(100,500,200,40);
        add(s3);
        
          s4= new JCheckBox("Cheque Book");
        s4.setFont(new Font("Raleway", Font.BOLD,16));
        s4.setBackground(Color.WHITE);
        s4.setBounds(300,500,200,40);
        add(s4);

          s5= new JCheckBox("E-Statement");
        s5.setFont(new Font("Raleway", Font.BOLD,16));
        s5.setBackground(Color.WHITE);
        s5.setBounds(100,550,200,40);
        add(s5);
        
         s6= new JCheckBox("E-mail & SMS Aleart");
        s6.setFont(new Font("Raleway", Font.BOLD,16));
        s6.setBackground(Color.WHITE);
        s6.setBounds(300,550,200,40);
        add(s6);

          s7= new JCheckBox("I here by declared that above details are correct to the best of my knowledge.");
        s7.setFont(new Font("Raleway", Font.BOLD,10));
        s7.setBackground(Color.WHITE);
        s7.setBounds(100,600,650,40);
        add(s7);
        
        ButtonGroup servicesrequired = new ButtonGroup();
        servicesrequired.add(s1);
                servicesrequired.add(s2);
                servicesrequired.add(s3);
                        servicesrequired.add(s4);
                        servicesrequired.add(s5);
                        servicesrequired.add(s6);
                        servicesrequired.add(s7);
                
                     
        submit = new JButton("SUBMIT");
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.setFont(new Font("Raleway", Font.BOLD,16));
        submit.setBounds(300,650,200,40);
        submit.addActionListener(this);
        add(submit);
        
         cancel = new JButton("CANCEL");
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.setFont(new Font("Raleway", Font.BOLD,16));
        cancel.setBounds(300,700,200,40);
        cancel.addActionListener(this);
        add(cancel);
        

        
               getContentPane().setBackground(Color.WHITE);

        setSize(850,820);
        setLocation(350,0);
        setVisible(true);
       }
    
    public void actionPerformed(ActionEvent ae){
    if (ae.getSource() == submit){
        String type = null;
        if (r1.isSelected()){
        type = "Saving Account"; }
        else if(r2.isSelected()){
        type = "Fixed Deposit Account"; }
         else if(r3.isSelected()){
        type = "Current Account"; }
         else if(r4.isSelected()){
        type = "Recurring Depostie Account"; }
        
        Random random = new Random();
        String cardnumber = "" + Math.abs(random.nextLong() %90000000L + 50409360000000L);
        String pinnumber ="" + Math.abs(random.nextLong()% 9000L +1000L);
        
        
        String facility = "";
        
        if(s1.isSelected()){
        facility = facility + "ATM Card"; }
        else if(s2.isSelected()){
         facility = facility + "Mobile Banking";}
         else if(s3.isSelected()){
         facility = facility + "Internet Banking";}
         else if(s4.isSelected()){
         facility = facility + "Cheque Book";}
         else if(s5.isSelected()){
         facility = facility + "E-Statement";}
         else if(s6.isSelected()){
         facility = facility + "E-mail & SMS Aleart";}

try {
    if (type == null){
    JOptionPane.showMessageDialog(null,"Account Type is not mentioned.");
    }else {
    Conn conn = new Conn();
    String query1 =  "insert into singupthree values('"+formno+"', '"+type+"', '"+cardnumber+"', '"+pinnumber+"','"+facility+"')" ;
     String query2 =  "insert into login values('"+formno+"','"+cardnumber+"', '"+pinnumber+"')"; 
   
     conn.s.executeUpdate(query1);
     conn.s.executeUpdate(query2);
    
     JOptionPane.showMessageDialog(null, "Card Number:" + cardnumber + "\n Pin" + pinnumber);
    }{
         setVisible(false);
new Deposit(pinnumber).setVisible(true);}
} catch (Exception e) {
System.out.println(e);
}      
        
    }else if (ae.getSource() == cancel){
        setVisible(false);
        new Login().setVisible(true);
    }
    }
    public static void main (String args[]){
    
    new SingupThree("");
    
    }
}
