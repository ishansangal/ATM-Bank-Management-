package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SingupTwo extends JFrame implements ActionListener{
    
  
    
    JTextField incomeTextField, educationalTextField,qualificationTextField , occupationTextField, panTextField, adharTextField;
            JButton next;
            JRadioButton syes, sno, eyes, eno;
           JComboBox relegion, category;
           String formno;
              
    SingupTwo(String formno){
        
        this.formno = formno;
         setLayout(null);
       
         setTitle("NEW APPLICATION FORM -- PAGE2");
       
        
          JLabel additionalDetails = new JLabel("Page 2: Additional Details");
        additionalDetails.setFont(new Font("Raleway",Font.BOLD,22));
         additionalDetails.setBounds(290,80,400,30);
        add( additionalDetails);
        
             JLabel sreligion = new JLabel("Religion:");
         sreligion.setFont(new Font("Raleway",Font.BOLD,20));
         sreligion.setBounds(100,140,100,30);
        add(sreligion);
        
        String valReligion [] = {"Hindu", "Muslim", "Sikh", "Christian", "Other"};
         relegion = new JComboBox (valReligion);
        relegion.setBackground(Color.WHITE);
        relegion.setBounds(300,140,400,30);
        add(relegion);
     
         
         JLabel scategory = new JLabel("Category:");
          scategory.setFont(new Font("Raleway",Font.BOLD,20));
        scategory.setBounds(100,190,350,30);
        add(scategory);
        
         String valCategory[] = {"General", "OBC", "SC", "ST"};
        category = new JComboBox (valCategory);
        category.setBackground(Color.WHITE);
        category.setBounds(300,190,400,30);
        add(category);
      
    
       JLabel income = new JLabel("Income:");
     income.setFont(new Font("Raleway",Font.BOLD,20));
     income.setBounds(100,240,400,30);
        add(    income);
        
                  incomeTextField = new JTextField();
         incomeTextField.setFont(new Font("Raleway", Font.BOLD,14));
        incomeTextField.setBounds(300,240,400,30);
        add(incomeTextField);

        
           JLabel educational = new JLabel("Educational:");
 educational.setFont(new Font("Raleway",Font.BOLD,20));
 educational.setBounds(100,290,150,30);
        add(   educational );
        
          educationalTextField = new JTextField();
         educationalTextField.setFont(new Font("Raleway", Font.BOLD,14));
        educationalTextField.setBounds(300,290,400,30);
        add(educationalTextField);
        
      
        
             JLabel qualification = new JLabel("Qualification:");
     qualification.setFont(new Font("Raleway",Font.BOLD,20));
     qualification.setBounds(100,340,150,30);
        add(qualification);
        
        
          qualificationTextField = new JTextField();
         qualificationTextField.setFont(new Font("Raleway", Font.BOLD,14));
        qualificationTextField.setBounds(300,340,400,30);
        add(qualificationTextField);
        
       
            JLabel occupation = new JLabel("Occupation:");
     occupation.setFont(new Font("Raleway",Font.BOLD,20));
       occupation.setBounds(100,390,150,30);
        add(    occupation);
        
         occupationTextField = new JTextField();
         occupationTextField.setFont(new Font("Raleway", Font.BOLD,14));
        occupationTextField.setBounds(300,390,400,30);
        add(occupationTextField);
      
        
         JLabel pan = new JLabel("PAN Number:");
     pan.setFont(new Font("Raleway",Font.BOLD,20));
       pan.setBounds(100,440,150,30);
        add(    pan);
        
           panTextField = new JTextField();
         panTextField.setFont(new Font("Raleway", Font.BOLD,14));
         panTextField.setBounds(300,440,400,30);
        add(panTextField);
        
         JLabel adhar = new JLabel("Adhar Number:");
     adhar.setFont(new Font("Raleway",Font.BOLD,20));
        adhar.setBounds(100,490,150,30);
        add(     adhar);
        
       adharTextField = new JTextField();
         adharTextField.setFont(new Font("Raleway", Font.BOLD,14));
         adharTextField.setBounds(300,490,400,30);
        add(adharTextField);
        
         JLabel seniorcitizen = new JLabel("Senior Citizen:");
     seniorcitizen.setFont(new Font("Raleway",Font.BOLD,20));
       seniorcitizen.setBounds(100,540,150,30);
        add(     seniorcitizen);
        
        
         syes = new JRadioButton("Yes");
        syes.setBackground(Color.WHITE);
        syes.setBounds(300,540,60,30);
        add(syes);
        
        
      sno = new JRadioButton("NO");
        sno.setBounds(400,540,60,30);
        sno.setBackground(Color.WHITE);
        add(sno);
        
        ButtonGroup seniorcitizengroup = new ButtonGroup();
        seniorcitizengroup.add(syes);
        seniorcitizengroup.add(sno);
        
      
        
        JLabel existing = new JLabel(" Existing Account:");
     existing.setFont(new Font("Raleway",Font.BOLD,20));
       existing.setBounds(100,590,200,30);
        add(      existing);
        
        eyes = new JRadioButton("Yes");
        eyes.setBackground(Color.WHITE);
        eyes.setBounds(300,590,60,30);
        add(eyes);
        
        
      eno = new JRadioButton("NO");
        eno.setBounds(400,590,60,30);
        eno.setBackground(Color.WHITE);
        add(eno);
        
        ButtonGroup existinggroup = new ButtonGroup();
        existinggroup.add(eyes);
        existinggroup.add(eno);
       
    
   next = new JButton("NEXT");
   next.setBackground(Color.BLACK);
   next.setForeground(Color.WHITE);
   next.setFont(new Font ("Raleway", Font.BOLD, 14));
   next.setBounds(620,660,80,30);
   next.addActionListener(this);
   add(next);
   
         getContentPane().setBackground(Color.WHITE);
         
        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
    }
   
public void actionPerformed(ActionEvent ae){
   
String sreligion = (String) relegion.getSelectedItem();
String scategory = (String) category.getSelectedItem();
String income = incomeTextField.getText();
String educational = educationalTextField.getText();
String qualification = qualificationTextField.getText();
String occupation = occupationTextField.getText();
String pan = panTextField.getText();
String adhar = adharTextField.getText();
String seniorcitizen = null;
if(syes.isSelected()){
    seniorcitizen = "Yes";
} else if(sno.isSelected()){
    seniorcitizen = "No";
   }

String existing = null;
if(eyes.isSelected()){
    existing = "Yes";
} else if(eno.isSelected()){
    existing = "No";
   }


try{
        Conn c = new Conn();
        String query = "insert into singuptwo values('"+formno+"', '"+sreligion+"', '"+scategory+"', '"+income+"',"
                        + "'"+educational+"', '"+qualification+"', '"+occupation+"', '"+pan+"', "
                         + "'"+adhar+"', '"+seniorcitizen+"', '"+existing+"')";
        c.s.executeUpdate(query);
        
setVisible(false);
new SingupThree(formno).setVisible(true);

}catch (Exception e){
    System.out.println(e);
}
}

    
    public static void main (String args[]){
        new SingupTwo(" ");
        
    }

}