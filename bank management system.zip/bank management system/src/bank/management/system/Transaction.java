package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Transaction extends JFrame implements ActionListener{
    
    JButton deposit, withdrawl,statement, fastcash ,balance,pinchange, exit ;
    String pinnumber; 

    Transaction(String pinnumber){
        this.pinnumber = pinnumber;
        
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900,900, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
          JLabel image = new JLabel(i3);
          image.setBounds(0,0,900,900);
          add(image);
          
          JLabel text = new JLabel("Please Select Your Transaction");
        text.setBounds(170,300,700,35);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("System",Font.BOLD,22));
        image.add(text);
        
       deposit = new JButton("Deposit");
       deposit.setBounds(150,420,150,30);
       deposit.setForeground(Color.BLACK);
       deposit.setFont(new Font("System", Font.BOLD,16));
       deposit.addActionListener(this);
       image.add(deposit);
       
        withdrawl = new JButton("Cash Withdrawl");
       withdrawl.setBounds(350,420,160,30);
       withdrawl.setForeground(Color.BLACK);
       withdrawl.setFont(new Font("System", Font.BOLD,16));
              withdrawl.addActionListener(this);
       image.add(withdrawl);
       
        statement = new JButton("Statement");
       statement.setBounds(150,460,150,30);
       statement.setForeground(Color.BLACK);
       statement.setFont(new Font("System", Font.BOLD,16));
              statement.addActionListener(this);
       image.add(statement);
       
       
        fastcash = new JButton("Fast Cash");
       fastcash.setBounds(350,460,160,30);
       fastcash.setForeground(Color.BLACK);
       fastcash.setFont(new Font("System", Font.BOLD,16));
              fastcash.addActionListener(this);

       image.add(fastcash);
       
         balance = new JButton("Balance Enquiry");
       balance.setBounds(150,500,150,30);
       balance.setForeground(Color.BLACK);
       balance.setFont(new Font("System", Font.BOLD,16));
       balance.addActionListener(this);
       image.add(balance);
       
       
        pinchange = new JButton("Pin Change");
       pinchange.setBounds(350,500,160,30);
       pinchange.setForeground(Color.BLACK);
       pinchange.setFont(new Font("System", Font.BOLD,16));
              pinchange.addActionListener(this);
       image.add(pinchange);
       
       
        exit = new JButton("Exit");
       exit.setBounds(350,540,160,30);
       exit.setForeground(Color.BLACK);
       exit.setFont(new Font("System", Font.BOLD,16));
              exit.addActionListener(this);
       image.add(exit);
       
       
        
        setSize(900,900);
        setLocation(300,0);
       setUndecorated(true);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == exit){
        System.exit(0);
                } else if (ae.getSource() == deposit) {
                setVisible(false);
                new Deposit(pinnumber).setVisible(true);
                } else if(ae.getSource() == withdrawl){
                setVisible(false);
                new Withdrawl(pinnumber).setVisible(true);
                } else if (ae.getSource() == fastcash){
                setVisible(false);
                new FastCash(pinnumber).setVisible(true);
    } else if (ae.getSource()  == pinchange){
    setVisible(false);
    new PinChange(pinnumber).setVisible(true);
    }else if (ae.getSource() == balance){
         setVisible(false);
    new BalanceEnquiry(pinnumber).setVisible(true);
    }else if (ae.getSource() == statement){
    new Statement(pinnumber).setVisible(true);
    }
    }
    
    public static void main(String args[]){
        new Transaction("");
    }
}
