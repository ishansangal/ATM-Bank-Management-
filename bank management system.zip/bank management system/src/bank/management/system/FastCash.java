package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;
public class FastCash extends JFrame implements ActionListener{
    
    JButton R1, R2,R3,R4,R5,R6,back ;
    String pinnumber; 
    private String withdrawl;

    FastCash(String pinnumber){
        this.pinnumber = pinnumber;
        
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900,900, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
          JLabel image = new JLabel(i3);
          image.setBounds(0,0,900,900);
          add(image);
          
          JLabel text = new JLabel("Select Withdrawl Amount");
        text.setBounds(170,300,700,35);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("System",Font.BOLD,22));
        image.add(text);
        
       R1 = new JButton("Rs. 100");
       R1.setBounds(150,420,150,30);
       R1.setForeground(Color.BLACK);
       R1.setFont(new Font("System", Font.BOLD,16));
       R1.addActionListener(this);
       image.add(R1);
       
        R2 = new JButton("Rs. 500");
       R2.setBounds(350,420,160,30);
       R2.setForeground(Color.BLACK);
       R2.setFont(new Font("System", Font.BOLD,16));
              R2.addActionListener(this);
       image.add(R2);
       
        R3 = new JButton("Rs. 1000");
       R3.setBounds(150,460,150,30);
       R3.setForeground(Color.BLACK);
       R3.setFont(new Font("System", Font.BOLD,16));
              R3.addActionListener(this);
       image.add(R3);
       
       
        R4 = new JButton("Rs. 2000");
       R4.setBounds(350,460,160,30);
       R4.setForeground(Color.BLACK);
       R4.setFont(new Font("System", Font.BOLD,16));
              R4.addActionListener(this);
         image.add(R4);
       
         R5 = new JButton("Rs. 5000");
       R5.setBounds(150,500,150,30);
       R5.setForeground(Color.BLACK);
       R5.setFont(new Font("System", Font.BOLD,16));
       R5.addActionListener(this);
       image.add(R5);
       
       
        R6 = new JButton("Rs. 10000");
       R6.setBounds(350,500,160,30);
       R6.setForeground(Color.BLACK);
       R6.setFont(new Font("System", Font.BOLD,16));
              R6.addActionListener(this);
       image.add(R6);
       
       
        back = new JButton("Back");
       back.setBounds(350,540,160,30);
       back.setForeground(Color.BLACK);
       back.setFont(new Font("System", Font.BOLD,16));
              back.addActionListener(this);
       image.add(back);
       
       
        
        setSize(900,900);
        setLocation(300,0);
       setUndecorated(true);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == back){
            setVisible(false);
            new Transaction(pinnumber).setVisible(true);
                        } else  {
String amount = ((JButton)ae.getSource()).getText().substring(3);
        Conn conn = new Conn();
        try {
ResultSet rs = conn.s.executeQuery("select * from bank where pin = '"+pinnumber+"'");
        int balance = 0;
        while(rs.next()){
        if (rs.getString("type").equals("Deposit")){
            balance += Integer.parseInt(rs.getString("amount"));
        }else{
            balance -= Integer.parseInt(rs.getString("amount"));
        }
    }
        if (ae.getSource() != back && balance < Integer.parseInt(amount)){
        JOptionPane.showMessageDialog(null,"Insufficient Balance");
        return;
        }
        Date date = new Date();
String query = "insert into bank values('"+pinnumber+"','"+date+"','"+withdrawl+"', '"+amount+"')";
        conn.s.executeUpdate(query);
        JOptionPane.showMessageDialog(null, "Rs "+amount+ "Debited Successfully");
        setVisible(false);
        new Transaction(pinnumber).setVisible(true);
        }catch (Exception e){
        System.out.println(e);
        }
       }
    }
    
    public static void main(String args[]){
        new FastCash("");
    }
}

